/** How to use.
 * The component expects few properties @interface FileUploadConfiguration to be passed.
 * @param width: can be any number between 1 to 5 which will range from Upload card width from
 * 20 % to 100% ( step of 20%). Default is 100%
 * @param multiple: Boolean value to allow selection of multiple file. True mean multiple is allowed.
 * Default is false.
 * @param type: Specifies type of import. Recommended is to pass 'File' as type. This is also set by default.
 * @param label: The string needed for upload card title. Can be left blank.
 * @param accept: Mandatory field. Provide the acceptable file formats.
 * @param icon: Angular material icon for upload.
 * @param uploadType: This can be 'DML', 'DDL', 'HTML' or 'CSS'. This is required by backend.
 */


import { Component, OnInit, ViewChild, ElementRef, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { UploadService } from 'src/app/services/http/upload.service';
import { FileUploadConfiguration } from './file-upload-configuration.model';
import { IProjectDetails, ProjectDetailService } from 'src/app/services/utility/project-detail.service';
import { NotificationService } from 'src/app/services/utility/notification.service';
import { ThemePalette } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogBoxComponent } from '../dialog-box/dialog-box.component';

export interface IFile {
  data: File;
  inProgress: boolean;
  progress: number;
  progressColor: ThemePalette;
  uploadStatus: string;
  error: any;
}

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})

export class FileUploadComponent implements OnInit, OnChanges {
  @ViewChild('fileUpload', {static: false}) fileUpload: ElementRef;
  files: Array<IFile>  = [];
  @Input() fileConfig: FileUploadConfiguration;
  @Output() updateFileListEmitter = new EventEmitter();
  projectDetail: IProjectDetails;
  accept: string;
  width = 'width: 100%';
  type = 'file';
  multiple = 'multiple';
  label: string;
  icon: string;

  constructor(private uploadService: UploadService,
              private projectDetailService: ProjectDetailService,
              private notificationService: NotificationService,
              public dialog: MatDialog) { }

  ngOnInit(): void {
    this.projectDetail = this.projectDetailService.getProjectDetails();
  }

  ngOnChanges(): void {
    this.resolveFileConfiguration();
  }

  resolveFileConfiguration() {
    this.accept = this.fileConfig.accept;
    this.fileConfig.label ? this.label = this.fileConfig.label : this.label = '';
    this.fileConfig.icon ? this.icon = this.fileConfig.icon : this.icon = '';
    this.fileConfig.multiple ? this.multiple = 'multiple' : this.multiple = '';
    if (this.fileConfig.width) {
      switch (this.fileConfig.width) {
        case 1: {
          this.width = 'width: 20%';
          break;
        }
        case 2: {
          this.width = 'width: 40%';
          break;
        }
        case 3: {
          this.width = 'width: 60%';
          break;
        }
        case 4: {
          this.width = 'width: 80%';
          break;
        }
        case 5: {
          this.width = 'width: 100%';
          break;
        }
        default: {
          this.width = 'width: 50%';
          break;
        }
      }
    }
  }

  uploadFile(file: IFile) {
    const formData = new FormData();
    formData.append('file', file.data);
    formData.append('fileName', file.data.name);
    formData.append('fileType', this.fileConfig.uploadType);
    formData.append('projectId', this.projectDetail.id);
    file.inProgress = true;
    this.uploadService.upload(formData).pipe(
      map(event => {
        switch (event.type) {
          case HttpEventType.UploadProgress:
            file.progress = Math.round(event.loaded * 100 / event.total);
            file.uploadStatus = 'done';
            break;
          case HttpEventType.Response:
            this.notificationService.notify({
              msg: 'File ' + file.data.name + ' uploaded successfully !!',
              color: 'alert-success'
            });
            this.notifyParentToUpdateFileList(this.fileConfig.uploadType);
            return event;
        }
      }),
      catchError((error: HttpErrorResponse) => {
        file.inProgress = false;
        file.progressColor = 'warn';
        file.uploadStatus = 'done';
        file.error = error;
        console.log('Looking at error response');
        console.log(file);
        this.notificationService.notify({
          msg: 'Uploading of File ' + file.data.name + ' failed !!',
          color: 'alert-error'
        });
        return of(`${file.data.name} upload failed.`);
      })).subscribe((event: any) => {
        if (typeof (event) === 'object') {
          console.log(event.body);
        }
      });
  }

  notifyParentToUpdateFileList(fileType: string) {
    this.updateFileListEmitter.emit(fileType);
  }

//   private uploadFiles(file: IFile) {
//     this.fileUpload.nativeElement.value = '';
//     this.files.forEach(file => {
//       this.uploadFile(file);
//     });
// }

  onClick() {
    const fileUpload = this.fileUpload.nativeElement; fileUpload.onchange = () => {
      const newIndex = fileUpload.files.length - 1;
      const file = fileUpload.files[newIndex];
      const fileObject: IFile = { data: file, inProgress: false, progress: 0, progressColor: 'primary', uploadStatus: 'new', error: []};
      this.files.push(fileObject);
      this.uploadFile(fileObject);
    };
    fileUpload.click();
}

  showError(errorObj: any) {
    let dialogRef = this.dialog.open(DialogBoxComponent, {data: errorObj});
    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialog Result');
    });
  }

}
