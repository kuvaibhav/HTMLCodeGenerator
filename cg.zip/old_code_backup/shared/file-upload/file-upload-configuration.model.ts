export interface FileUploadConfiguration {
  width?: number;
  accept: string;
  type?: string;
  multiple?: boolean;
  label?: string;
  icon?: string;
  uploadType: string;
}
