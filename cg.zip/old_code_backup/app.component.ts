import { Component, HostListener, EventEmitter } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragEnd } from '@angular/cdk/drag-drop';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'IRA-Client';

  mouseup = new EventEmitter<MouseEvent>();
  mousedown = new EventEmitter<MouseEvent>();
  mousemove = new EventEmitter<MouseEvent>();
  showTextBox = false;
  restrictMovement = false;
  restrictBoundary = '';

  mousedrag: Observable<{top, left}>;

  @HostListener('document:mouseup', ['$event'])
  onMouseup(event: MouseEvent) {
      this.mouseup.emit(event);
      // console.log('Mouse Up');
  }

  @HostListener('mousedown', ['$event'])
  onMousedown(event: MouseEvent) {
      this.mousedown.emit(event);
      // console.log('Mouse Down');
      return false; // Call preventDefault() on the event
      
  }

  @HostListener('document:mousemove', ['$event'])
  onMousemove(event: MouseEvent) {
      this.mousemove.emit(event);
      // console.log('Mouse Doc Move');
  }

  todos = [
    {
      name:'Item 1',
      category:'E.g. Text Box'
    },
    {
      name:'Item 2',
      category:'E.g. Button'
    },
    {
      name:'Item 3',
      category:'E.g. Label'
    },
    {
      name:'Item 4',
      category:'E.g. Radio Button'
    }
  ];

  completed = [
    {
      name:'Item 5',
      category:'E.g. CheckBox'
    },
    {
      name:'Item 6',
      category:'E.g. Text Area'
    },
    {
      name:'Item 7',
      category:'E.g. DropDown'
    },
    {
      name:'Item 8',
      category:'E.g. Header'
    }
  ];

  onDrop(event: CdkDragDrop<string[]>) {
    // console.log(event);
    if(event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      this.showTextBox = true;
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }
  }

  dropBox(event: CdkDragDrop<any[]>) {
    // console.log(event);
  }

  dragEnded($event: CdkDragEnd) {
    console.log(event);
    const { offsetLeft, offsetTop } = $event.source.element.nativeElement;
    const { x, y } = $event.distance;
    let positionX = offsetLeft + x;
    let positionY = offsetTop + y;
    // this.showPopup = true;
    // console.log({ positionX, positionY });
  }

  checkDragEnded($event: CdkDragEnd) {
    const nativeElement = $event.source.element.nativeElement;
    // console.log(nativeElement);
  }

  dragRestrictedEnded($event: CdkDragEnd) {
    const { offsetLeft, offsetTop } = $event.source.element.nativeElement;
    const { x, y } = $event.distance;
    let positionX = offsetLeft + x;
    let positionY = offsetTop + y;
    // this.showPopup = true;
    // console.log({ positionX, positionY });
    if ((positionX > 0 && positionX < 200) && (positionY < 300 && positionY > -200)) {
      this.restrictMovement = true;
      this.restrictBoundary = '.example-boundary';
    } else {
      this.restrictMovement = false;
    }
  }

  listenToClick(event) {
    console.log('Listening');
  }
}
