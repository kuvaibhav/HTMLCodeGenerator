import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComittedComponent } from './comitted.component';

describe('ComittedComponent', () => {
  let component: ComittedComponent;
  let fixture: ComponentFixture<ComittedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComittedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComittedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
