import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comitted',
  templateUrl: './comitted.component.html',
  styleUrls: ['./comitted.component.css']
})
export class ComittedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
