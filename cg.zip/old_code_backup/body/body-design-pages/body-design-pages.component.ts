import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-design-pages',
  templateUrl: './body-design-pages.component.html',
  styleUrls: ['./body-design-pages.component.css']
})
export class BodyDesignPagesComponent implements OnInit {
  pageCount;

  constructor() { }

  ngOnInit() {
    // Write a backend service call to fetch the number of pages
    this.pageCount = [1,2,3,4];
  }

}
