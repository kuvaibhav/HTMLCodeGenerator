import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BodyDesignPagesComponent } from './body-design-pages.component';

describe('BodyDesignPagesComponent', () => {
  let component: BodyDesignPagesComponent;
  let fixture: ComponentFixture<BodyDesignPagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BodyDesignPagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BodyDesignPagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
