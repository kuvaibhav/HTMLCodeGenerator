import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

interface PageLayout {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-basic-info',
  templateUrl: './basic-info.component.html',
  styleUrls: ['./basic-info.component.css']
})
export class BasicInfoComponent implements OnInit {
  basicInfoForm: FormGroup;
  pageLayouts: PageLayout[] = [
    {value: 'H-B-F', viewValue: 'Header-Body-Footer'},
    {value: 'H-B', viewValue: 'Header-Body'},
    {value: 'H-N-B-F', viewValue: 'Header-Navbar-Body-Footer'},
    {value: 'H-N-B-F-S', viewValue: 'Header-Navbar-Body-Footer-Sidebar'},
    {value: 'H-N-B-S', viewValue: 'Header-Navbar-Body-Sidebar'}
  ];
  selectedLayout: string;

  constructor() { }

  ngOnInit() {
    this.selectedLayout = '';
  }

  detectPageLayout() {
    console.log(this.selectedLayout);
  }

}
