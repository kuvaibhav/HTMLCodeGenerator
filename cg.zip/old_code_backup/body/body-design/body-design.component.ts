import { Component, OnInit, HostListener, EventEmitter } from '@angular/core';
import { CdkDragEnd } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-body-design',
  templateUrl: './body-design.component.html',
  styleUrls: ['./body-design.component.css']
})
export class BodyDesignComponent implements OnInit {
  mouseX: number;
  mouseY: number;
  clientX: number;
  clientY: number;
  offsetX: number;
  offsetY: number;
  pageX: number;
  pageY: number;
  calibratedX: number;
  calibratedY: number;
  isNonCalibrated = true;
  mousemove = new EventEmitter<MouseEvent>();

  constructor() { }

  ngOnInit() {
  }

  @HostListener('document:mousemove', ['$event'])
  onMousemove(event: MouseEvent) {
      this.mousemove.emit(event);
      this.mouseX = event.screenX;
      this.mouseY = event.screenY;
      this.clientX = event.clientX;
      this.clientY = event.clientY;
      this.offsetX = event.offsetX;
      this.offsetY = event.offsetY;
      this.pageX = event.pageX;
      this.pageY = event.pageY;
      // console.log(event);
      // console.log('Mouse Doc Move');
  }

  dragEnded($event: CdkDragEnd) {
    console.log(event);
    const { offsetLeft, offsetTop } = $event.source.element.nativeElement;
    const { x, y } = $event.distance;
    let positionX = offsetLeft + x;
    let positionY = offsetTop + y;
    // this.showPopup = true;
    // console.log({ positionX, positionY });
  }

  calibrateSanbox($event: MouseEvent) {
    this.calibratedX = 0;
    this.calibratedY = 0;
    this.calibratedX = $event.clientX - $event.offsetX;
    this.calibratedY = $event.clientY - $event.offsetY; 
    this.isNonCalibrated = false;
    console.log($event);
  }

}
