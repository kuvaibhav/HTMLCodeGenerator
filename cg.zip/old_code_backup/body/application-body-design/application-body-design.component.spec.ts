import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationBodyDesignComponent } from './application-body-design.component';

describe('ApplicationBodyDesignComponent', () => {
  let component: ApplicationBodyDesignComponent;
  let fixture: ComponentFixture<ApplicationBodyDesignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationBodyDesignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationBodyDesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
