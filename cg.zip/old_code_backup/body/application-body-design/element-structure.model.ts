export interface ElementStructureModel {
    title: string;
    position: any;
    buttonText: string;
    fieldName: string;
    code: string;
}

export interface WebComponentModel {
    id: string;
    webElement: string;
    backgroundColor: ComponentThemeModel;
    label: string;
}

export interface ComponentThemeModel {
    name: string;
    style: any;
}
