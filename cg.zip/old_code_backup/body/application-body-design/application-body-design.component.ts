import { Component, OnInit, ViewChild, AfterViewInit, Input } from '@angular/core';
import { ElementMetadataFactoryService } from 'src/app/utility-services/element-metadata-factory.service';
import { ElementStructureModel, WebComponentModel } from './element-structure.model';
import { SandboxComponent } from './sandbox/sandbox.component';
import { FormGroup, FormControl } from '@angular/forms';
import * as grid from '../../../assets/grid-dropdowns/grid.json';
declare var $;

@Component({
  selector: 'app-application-body-design',
  templateUrl: './application-body-design.component.html',
  styleUrls: ['./application-body-design.component.css']
})
export class ApplicationBodyDesignComponent implements OnInit, AfterViewInit {
  @Input() currentPage;
  openSideBar = false;
  sideBarTitle: string;
  metadata: ElementStructureModel;
  webComponent: WebComponentModel;
  gridSelectionForm: FormGroup;
  selectedGrid: any;
  gridSpec = [];
  addWebComponentSpecs: any = (grid as any).default;
  selectedField = '';

  componentThemes = [
    {"name": "Electric Red", "style": {'background-color': '#ff0028', 'color': '#FFFFFF'}},
    {"name": "Deep Green", "style": {'background-color': '#657a00', 'color': '#FFFFFF'}},
    {"name": "Power Blue", "style": {'background-color': '#1400c6', 'color': '#FFFFFF'}},
    {"name": "Background Tan", "style": {'background-color': '#fceed1', 'color': '#000000'}},
    {"name": "Purple", "style": {'background-color': '#7d3cff', 'color': '#FFFFFF'}},
    {"name": "Redhead", "style": {'background-color': '#c80e13', 'color': '#FFFFFF'}},
    {"name": "Sand Tan", "style": {'background-color': '#e1b382', 'color': '#000000'}},
    {"name": "Night Blue", "style": {'background-color': '#2d545e', 'color': '#FFFFFF'}},
    {"name": "Night Blue Shadow", "style": {'background-color': '#12343b', 'color': '#FFFFFF'}},
    {"name": "Coral Pink", "style": {'background-color': '#ff5e6c', 'color': '#000000'}},
    {"name": "Sleuthe Yellow", "style": {'background-color': '#feb300', 'color': '#FFFFFF'}},
    {"name": "Pink Leaf", "style": {'background-color': '#ffaaab', 'color': '#FFFFFF'}},
    {"name": "Mountain Pink", "style": {'background-color': '#f9c5bd', 'color': '#000000'}},
    {"name": "Green Treeline", "style": {'background-color': '#478559', 'color': '#FFFFFF'}},
    {"name": "White Layover", "style": {'background-color': '#fffff', 'color': '#000000'}},
    {"name": "Orange Circle", "style": {'background-color': '#ff8928', 'color': '#000000'}}
  ]

  @ViewChild(SandboxComponent, {static: false}) sandboxComponent: SandboxComponent;

  constructor(private _elementMetaDataFactory: ElementMetadataFactoryService) { }

  ngOnInit() {
    $('.shape').shape();
    this.gridSpec = this.addWebComponentSpecs['gridSpec'];
    this.gridSelectionForm = new FormGroup({
      'grid': new FormControl(null),
      'component': new FormControl(null),
      'componentTheme': new FormControl(null),
      'label': new FormControl('Default Label')
    });
  }

  ngAfterViewInit() {

  }

    flip() {
    $('.shape').shape('flip up');
  }

  requestElementDetails(elementName) {
  this.metadata = this._elementMetaDataFactory.retrieveElementMetaData(elementName);
  this.selectedField = this.metadata.fieldName;
  this.openSideBar = true;
  }

  addElementAndCloseSidebar() {
    this.webComponent = {id: this.gridSelectionForm.value.grid, webElement: this.metadata.code, 
      backgroundColor: this.gridSelectionForm.value.componentTheme, label: this.gridSelectionForm.value.label};
    this.sandboxComponent.addElementtoGrid(this.webComponent);
    this.openSideBar = false;
  }

}
