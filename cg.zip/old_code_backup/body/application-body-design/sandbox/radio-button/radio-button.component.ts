import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-radio-button',
  templateUrl: './radio-button.component.html',
  styleUrls: ['./radio-button.component.css']
})
export class RadioButtonComponent implements OnInit {
  @ViewChild('rb', {static: false}) radioButton;
  label: string;

  constructor() { }

  ngOnInit() {
  }

  fetchDOM(label?: string) {
    if (label) {
      this.label = label;
    }
    return this.radioButton;
  }

}
