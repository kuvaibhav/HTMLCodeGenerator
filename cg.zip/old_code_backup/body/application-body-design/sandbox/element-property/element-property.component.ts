import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-element-property',
  templateUrl: './element-property.component.html',
  styleUrls: ['./element-property.component.css']
})
export class ElementPropertyComponent implements OnInit {
  @Input() webComponentMetadata;

  constructor() { }

  ngOnInit() {
  }

}
