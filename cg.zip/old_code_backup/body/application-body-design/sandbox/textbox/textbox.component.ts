import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-textbox',
  templateUrl: './textbox.component.html',
  styleUrls: ['./textbox.component.css']
})
export class TextboxComponent implements OnInit {
  @ViewChild('tb', {static: false}) textBox;
  label = '';

  constructor() { }

  ngOnInit() {
  }

  fetchDOM(label?: string) {
    if (label) {
    this.label = label;
    }
    return this.textBox;
  }

}
