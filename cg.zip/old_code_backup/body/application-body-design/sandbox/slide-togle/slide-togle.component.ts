import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-slide-togle',
  templateUrl: './slide-togle.component.html',
  styleUrls: ['./slide-togle.component.css']
})
export class SlideTogleComponent implements OnInit {
  @ViewChild('st', {static: false}) slideToggle;
  label: string;

  constructor() { }

  ngOnInit() {
  }

  fetchDOM(label?: string) {
    if (label) {
      this.label = label;
    }
    return this.slideToggle;
  }

}
