import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-blue-button',
  templateUrl: './blue-button.component.html',
  styleUrls: ['./blue-button.component.css']
})
export class BlueButtonComponent implements OnInit {
  @ViewChild('prbtn', {static: false}) raisedBlueButton;
  label: string;
  constructor() { }

  ngOnInit() {
  }

  fetchDOM(label?: string) {
    if (label) {
      this.label = label;
    }
    return this.raisedBlueButton;
  }

}
