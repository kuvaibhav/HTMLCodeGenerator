import { Component, ViewChild, ViewContainerRef, ElementRef, Renderer2, ViewChildren, Input, TemplateRef } from '@angular/core';
import { WebComponentModel } from '../element-structure.model';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { RadioButtonComponent } from './radio-button/radio-button.component';
import { TextboxComponent } from './textbox/textbox.component';
import { SlideTogleComponent } from './slide-togle/slide-togle.component';
import { BlueButtonComponent } from './blue-button/blue-button.component';

@Component({
  selector: 'app-sandbox',
  templateUrl: './sandbox.component.html',
  styleUrls: ['./sandbox.component.css']
})
export class SandboxComponent {
  @Input() currentPage;
  // DOM Template Variable
  @ViewChild('currentDOM', {read: ElementRef, static: false}) dom: ElementRef;

  // Grid Template variables
  @ViewChild('zerozero', {read: ViewContainerRef, static: false}) zerozero: ViewContainerRef;
  @ViewChild('zeroone', {read: ViewContainerRef, static: false}) zeroone: ViewContainerRef;
  @ViewChild('zerotwo', {read: ViewContainerRef, static: false}) zerotwo: ViewContainerRef;
  @ViewChild('zerothree', {read: ViewContainerRef, static: false}) zerothree: ViewContainerRef;
  @ViewChild('zerofour', {read: ViewContainerRef, static: false}) zerofour: ViewContainerRef;
  @ViewChild('zerofive', {read: ViewContainerRef, static: false}) zerofive: ViewContainerRef;

  @ViewChild('onezero', {read: ViewContainerRef, static: false}) onezero: ViewContainerRef;
  @ViewChild('oneone', {read: ViewContainerRef, static: false}) oneone: ViewContainerRef;
  @ViewChild('onetwo', {read: ViewContainerRef, static: false}) onetwo: ViewContainerRef;
  @ViewChild('onethree', {read: ViewContainerRef, static: false}) onethree: ViewContainerRef;
  @ViewChild('onefour', {read: ViewContainerRef, static: false}) onefour: ViewContainerRef;
  @ViewChild('onefive', {read: ViewContainerRef, static: false}) onefive: ViewContainerRef;

  @ViewChild('twozero', {read: ViewContainerRef, static: false}) twozero: ViewContainerRef;
  @ViewChild('twoone', {read: ViewContainerRef, static: false}) twoone: ViewContainerRef;
  @ViewChild('twotwo', {read: ViewContainerRef, static: false}) twotwo: ViewContainerRef;
  @ViewChild('twothree', {read: ViewContainerRef, static: false}) twothree: ViewContainerRef;
  @ViewChild('twofour', {read: ViewContainerRef, static: false}) twofour: ViewContainerRef;
  @ViewChild('twofive', {read: ViewContainerRef, static: false}) twofive: ViewContainerRef;

  @ViewChild('threezero', {read: ViewContainerRef, static: false}) threezero: ViewContainerRef;
  @ViewChild('threeone', {read: ViewContainerRef, static: false}) threeone: ViewContainerRef;
  @ViewChild('threetwo', {read: ViewContainerRef, static: false}) threetwo: ViewContainerRef;
  @ViewChild('threethree', {read: ViewContainerRef, static: false}) threethree: ViewContainerRef;
  @ViewChild('threefour', {read: ViewContainerRef, static: false}) threefour: ViewContainerRef;
  @ViewChild('threefive', {read: ViewContainerRef, static: false}) threefive: ViewContainerRef;

  @ViewChild('fourzero', {read: ViewContainerRef, static: false}) fourzero: ViewContainerRef;
  @ViewChild('fourone', {read: ViewContainerRef, static: false}) fourone: ViewContainerRef;
  @ViewChild('fourtwo', {read: ViewContainerRef, static: false}) fourtwo: ViewContainerRef;
  @ViewChild('fourthree', {read: ViewContainerRef, static: false}) fourthree: ViewContainerRef;
  @ViewChild('fourfour', {read: ViewContainerRef, static: false}) fourfour: ViewContainerRef;
  @ViewChild('fourfive', {read: ViewContainerRef, static: false}) fourfive: ViewContainerRef;
  
  @ViewChild('fivezero', {read: ViewContainerRef, static: false}) fivezero: ViewContainerRef;
  @ViewChild('fiveone', {read: ViewContainerRef, static: false}) fiveone: ViewContainerRef;
  @ViewChild('fivetwo', {read: ViewContainerRef, static: false}) fivetwo: ViewContainerRef;
  @ViewChild('fourthree', {read: ViewContainerRef, static: false}) fivethree: ViewContainerRef;
  @ViewChild('fivefour', {read: ViewContainerRef, static: false}) fivefour: ViewContainerRef;
  @ViewChild('fivefive', {read: ViewContainerRef, static: false}) fivefive: ViewContainerRef;

  @ViewChild('zerozero', {read: ElementRef, static: false}) zerozeroE: ElementRef;
  @ViewChild('zeroone', {read: ElementRef, static: false}) zerooneE: ElementRef;
  @ViewChild('zerotwo', {read: ElementRef, static: false}) zerotwoE: ElementRef;
  @ViewChild('zerothree', {read: ElementRef, static: false}) zerothreeE: ElementRef;
  @ViewChild('zerofour', {read: ElementRef, static: false}) zerofourE: ElementRef;
  @ViewChild('zerofive', {read: ElementRef, static: false}) zerofiveE: ElementRef;

  @ViewChild('onezero', {read: ElementRef, static: false}) onezeroE: ElementRef;
  @ViewChild('oneone', {read: ElementRef, static: false}) oneoneE: ElementRef;
  @ViewChild('onetwo', {read: ElementRef, static: false}) onetwoE: ElementRef;
  @ViewChild('onethree', {read: ElementRef, static: false}) onethreeE: ElementRef;
  @ViewChild('onefour', {read: ElementRef, static: false}) onefourE: ElementRef;
  @ViewChild('onefive', {read: ElementRef, static: false}) onefiveE: ElementRef;

  @ViewChild('twozero', {read: ElementRef, static: false}) twozeroE: ElementRef;
  @ViewChild('twoone', {read: ElementRef, static: false}) twooneE: ElementRef;
  @ViewChild('twotwo', {read: ElementRef, static: false}) twotwoE: ElementRef;
  @ViewChild('twothree', {read: ElementRef, static: false}) twothreeE: ElementRef;
  @ViewChild('twofour', {read: ElementRef, static: false}) twofourE: ElementRef;
  @ViewChild('twofive', {read: ElementRef, static: false}) twofiveE: ElementRef;

  @ViewChild('threezero', {read: ElementRef, static: false}) threezeroE: ElementRef;
  @ViewChild('threeone', {read: ElementRef, static: false}) threeoneE: ElementRef;
  @ViewChild('threetwo', {read: ElementRef, static: false}) threetwoE: ElementRef;
  @ViewChild('threethree', {read: ElementRef, static: false}) threethreeE: ElementRef;
  @ViewChild('threefour', {read: ElementRef, static: false}) threefourE: ElementRef;
  @ViewChild('threefive', {read: ElementRef, static: false}) threefiveE: ElementRef;

  @ViewChild('fourzero', {read: ElementRef, static: false}) fourzeroE: ElementRef;
  @ViewChild('fourone', {read: ElementRef, static: false}) fouroneE: ElementRef;
  @ViewChild('fourtwo', {read: ElementRef, static: false}) fourtwoE: ElementRef;
  @ViewChild('fourthree', {read: ElementRef, static: false}) fourthreeE: ElementRef;
  @ViewChild('fourfour', {read: ElementRef, static: false}) fourfourE: ElementRef;
  @ViewChild('fourfive', {read: ElementRef, static: false}) fourfiveE: ElementRef;
  
  @ViewChild('fivezero', {read: ElementRef, static: false}) fivezeroE: ElementRef;
  @ViewChild('fiveone', {read: ElementRef, static: false}) fiveoneE: ElementRef;
  @ViewChild('fivetwo', {read: ElementRef, static: false}) fivetwoE: ElementRef;
  @ViewChild('fourthree', {read: ElementRef, static: false}) fivethreeE: ElementRef;
  @ViewChild('fivefour', {read: ElementRef, static: false}) fivefourE: ElementRef;
  @ViewChild('fivefive', {read: ElementRef, static: false}) fivefiveE: ElementRef;

  //webcomponents template variables
  //Each of webcomponent return type is of type Template Ref but Typescript complains when we try to strong type it.
  @ViewChild(CheckboxComponent, {static: false}) checkBox: CheckboxComponent;
  @ViewChild(RadioButtonComponent, {static: false}) radioButton: RadioButtonComponent;
  @ViewChild(TextboxComponent, {static: false}) textBox: TextboxComponent;
  @ViewChild(SlideTogleComponent, {static: false}) slideToggle: SlideTogleComponent;
  @ViewChild(BlueButtonComponent, {static: false}) blueRaisedButton: BlueButtonComponent;
  constructor(private renderer: Renderer2) { }

  addElementtoGrid(webComponent: WebComponentModel) {
    let grid = this.identifyGrid(webComponent.id);
    let webComponentTemRef = this.identifyWebComponent(webComponent.webElement, webComponent.label);
    let gridDOMRef = grid.gridElement;
    let gridViewRef = grid.gridView;
    gridDOMRef.nativeElement.textContent = '';
    let parentElement = gridDOMRef.nativeElement.parentNode;

    gridViewRef.createEmbeddedView(webComponentTemRef);
    /* Remember !! parent element referred here is always native elemenet. 
       Angular renderer 2 will work only on native element.
       If Element Ref is used we need to iterate one level down to access native element */ 
    this.renderer.setStyle(parentElement, 'backgroundColor', webComponent.backgroundColor.style['background-color']);
  }

  identifyGrid(gridId: string): {gridElement: ElementRef, gridView: ViewContainerRef} {
    switch(gridId) {
      case '#zerozero':
        return {gridElement: this.zerozeroE, gridView: this.zerozero};
      case '#zeroone':
        return {gridElement: this.zerooneE, gridView: this.zeroone};
      case '#zerotwo':
        return {gridElement: this.zerotwoE, gridView: this.zerotwo};
      case '#zerothree':
        return {gridElement: this.zerothreeE, gridView: this.zerothree};
      case '#zerofour':
        return {gridElement: this.zerofourE, gridView: this.zerofour};
      case '#zerofive':
        return {gridElement: this.zerofiveE, gridView: this.zerofive};
      case '#onezero':
        return {gridElement: this.onezeroE, gridView: this.onezero};
      case '#oneone':
        return {gridElement: this.oneoneE, gridView: this.oneone};
      case '#onetwo':
        return {gridElement: this.onetwoE, gridView: this.onetwo};
      case '#onethree':
        return {gridElement: this.onethreeE, gridView: this.onethree};
      case '#onefour':
        return {gridElement: this.onefourE, gridView: this.onefour};
      case '#onefive':
        return {gridElement: this.onefiveE, gridView: this.onefive};
      case '#twozero':
        return {gridElement: this.twozeroE, gridView: this.twozero};    
      case '#twothree':
        return {gridElement: this.twothreeE, gridView: this.twothree};
      case '#twofour':
        return {gridElement: this.twofourE, gridView: this.twofour};
      case '#twofive':
        return {gridElement: this.twofiveE, gridView: this.twofive};
      case '#threezero':
        return {gridElement: this.threezeroE, gridView: this.threezero};
      case '#threeone':
        return {gridElement: this.threeoneE, gridView: this.threeone};
      case '#threetwo':
        return {gridElement: this.threetwoE, gridView: this.threetwo};
    }
    return {gridElement: this.zerozeroE, gridView: this.zerozero};
  }

  identifyWebComponent(componentCode: string, label?: string) : TemplateRef<ElementRef>  {
    switch(componentCode) {
      case 'tb':
        return this.textBox.fetchDOM(label);
      case 'cb':
        return this.checkBox.fetchDOM(label);
      case 'rb':
        return this.radioButton.fetchDOM(label);
      case 'st':
        return this.slideToggle.fetchDOM(label);
      case 'prbtn':
        return this.blueRaisedButton.fetchDOM(label);
    }
  }

  listenToGridClick(gridId: string) {
    let grid = this.identifyGrid(gridId);
    let gridDOMRef = grid.gridElement;
    let gridViewRef = grid.gridView;
    // console.log(this.dom.nativeElement);
    // console.log(this.dom);
    // console.log(gridDOMRef);
    this.createPageObject();
  }

  createPageObject() {
    let pageObject = {
      projectId: 'Sample Project',
      pageId: this.currentPage,
      domTree: this.dom
  }
  console.log(pageObject);
}

}
