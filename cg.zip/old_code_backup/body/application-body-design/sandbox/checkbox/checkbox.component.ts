import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent implements OnInit {
  @ViewChild('cb', {static: false}) checkBox;
  label: string;

  constructor() { }

  ngOnInit() {
  }

  fetchDOM(label?: string) {
    this.label = label;
    return this.checkBox;
  }

}
