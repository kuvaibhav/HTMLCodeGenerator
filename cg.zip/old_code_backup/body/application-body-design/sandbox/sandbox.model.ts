import { ElementRef, TemplateRef } from '@angular/core';

export interface WebComponentModel {
    componentElementRef: TemplateRef<ElementRef>;
}