import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FileUploadConfiguration } from 'src/app/shared/file-upload/file-upload-configuration.model';
import { UploadService } from 'src/app/services/http/upload.service';
import { ProjectDetailService, IProjectDetails } from 'src/app/services/utility/project-detail.service';

export interface IUploadedFile {
  id: string;
  fileName: string;
  fileType: string;
  projectId: string;
}

@Component({
  selector: 'app-upload-section',
  templateUrl: './upload-section.component.html',
  styleUrls: ['./upload-section.component.css']
})
export class UploadSectionComponent implements OnInit {
  projectDetails: IProjectDetails;
  panelOpenState: boolean;
  uploadedDMLFiles: Array<IUploadedFile> = [];
  uploadedDDLFiles: Array<IUploadedFile> = [];
  uploadedHTMLFiles: Array<IUploadedFile> = [];
  uploadedCSSFiles: Array<IUploadedFile> = [];
  ddlFileConfiguration: FileUploadConfiguration;
  dmlFileConfiguration: FileUploadConfiguration;
  htmlFileConfiguration: FileUploadConfiguration;
  cssFileConfiguration: FileUploadConfiguration;
  showUploadedDDLFiles = false;
  showUploadedDMLFiles = false;
  showUploadedHTMLFiles = false;
  showUploadedCSSFiles = false;

  constructor(private uploadService: UploadService,
              private projectDetailService: ProjectDetailService) { }

  ngOnInit(): void {
    this.projectDetails = this.projectDetailService.getProjectDetails();
    this.fetchDDLFiles();
    this.fetchDMLFiles();
    this.fetchHTMLFiles();
    this.fetchCSSFiles();
    this.setDDLSqlConfigurations();
    this.setDMLSqlConfigurations();
    this.setHTMLConfiguration();
    this.setCSSConfiguration();
  }

  fetchDDLFiles() {
    this.uploadService.fetchUploadedFile(this.projectDetails.id, 'DDL')
      .subscribe((res: Array<IUploadedFile>) => {
        this.uploadedDDLFiles = res;
      });
  }

  fetchDMLFiles() {
    this.uploadService.fetchUploadedFile(this.projectDetails.id, 'DML')
      .subscribe((res: Array<IUploadedFile>) => {
        this.uploadedDMLFiles = res;
      });
  }

  fetchCSSFiles() {
    this.uploadService.fetchUploadedFile(this.projectDetails.id, 'CSS')
      .subscribe((res: Array<IUploadedFile>) => {
        this.uploadedCSSFiles = res;
      });
  }

  fetchHTMLFiles() {
    this.uploadService.fetchUploadedFile(this.projectDetails.id, 'HTML')
      .subscribe((res: Array<IUploadedFile>) => {
        this.uploadedHTMLFiles = res;
      });
  }

  setDDLSqlConfigurations() {
    this.ddlFileConfiguration = {
      accept: '.sql',
      multiple: true,
      icon: 'file_upload',
      width: 3,
      label: 'Upload DDL',
      uploadType: 'DDL'
    };
  }

  setDMLSqlConfigurations() {
    this.dmlFileConfiguration = {
      accept: '.sql',
      multiple: true,
      icon: 'file_upload',
      width: 4,
      label: 'Upload DML',
      uploadType: 'DML'
    };
  }

  setHTMLConfiguration() {
    this.htmlFileConfiguration = {
      accept: '.html',
      multiple: true,
      icon: 'file_upload',
      width: 4,
      label: 'Upload HTML',
      uploadType: 'HTML'
    };
  }

  setCSSConfiguration() {
    this.cssFileConfiguration = {
      accept: '.css',
      multiple: true,
      icon: 'file_upload',
      width: 4,
      label: 'Upload CSS',
      uploadType: 'CSS'
    };
  }

  flipShowDDL() {
    this.showUploadedDDLFiles = !this.showUploadedDDLFiles;
  }

  flipShowDML() {
    this.showUploadedDMLFiles = !this.showUploadedDMLFiles;
  }

  flipShowHTML() {
    this.showUploadedHTMLFiles = !this.showUploadedHTMLFiles;
  }

  flipShowCSS() {
    this.showUploadedCSSFiles = !this.showUploadedCSSFiles;
  }

  listenToFileUpload($event) {
    switch ($event) {
      case 'DDL': {
        this.fetchDDLFiles();
        break;
      }
      case 'DML': {
        this.fetchDMLFiles();
        break;
      }
      case 'HTML': {
        this.fetchHTMLFiles();
        break;
      }
      case 'CSS': {
        this.fetchCSSFiles();
        break;
      }
    }
  }
}
