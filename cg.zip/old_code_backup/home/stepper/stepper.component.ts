import { Component, OnInit } from '@angular/core';
import { FormGroup} from '@angular/forms';
import { Router } from '@angular/router';
import { ProjectDetailService, IProjectDetails } from 'src/app/services/utility/project-detail.service';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.css']
})
export class StepperComponent implements OnInit {
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  projectDetails: IProjectDetails;

  constructor(private router: Router,
              private projectDetailService: ProjectDetailService) {}

  ngOnInit(): void {
    this.projectDetails = this.projectDetailService.getProjectDetails();
}

openLandingPage() {
  this.router.navigate(['/home/dashboard']);
}
}
