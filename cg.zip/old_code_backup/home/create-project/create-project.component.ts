import * as _moment from 'moment';
import { Component, OnInit } from '@angular/core';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Moment, default as _rollupMoment } from 'moment';
import { CreateProjectAuthService } from '../../services/http/create-project.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/services/utility/notification.service';
import { IProjectDetails, ProjectDetailService } from 'src/app/services/utility/project-detail.service';

const moment = _rollupMoment || _moment;

export const DATE_FORMAT = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: DATE_FORMAT },
  ],
})

export class CreateProjectComponent implements OnInit {
  createProjectForm: FormGroup;
  showSpinner = false;
  errorMessage = '';
  formattedStartDate = '';
  formattedEndDate = '';
  userRoles = [];
  currentUser;
  selectedUserDetails;

  constructor(private createProjectService: CreateProjectAuthService,
              private snackBar: MatSnackBar,
              private router: Router,
              private notificationService: NotificationService,
              private projectDetailService: ProjectDetailService) { }

  ngOnInit() {
    this.initializeProjectForm();
    this.currentUser = localStorage.getItem('token');
    this.getAllUsers();
}

initializeProjectForm() {
  this.createProjectForm = new FormGroup({
    projectName: new FormControl('', Validators.required),
    projectDescription: new FormControl(null),
    startDate: new FormControl(moment(), Validators.required),
    endDate: new FormControl(''),
    adminAccess: new FormControl(''),
    developerAccess: new FormControl('')
  });
}

getAllUsers() {
  this.createProjectService.getAllUsers().subscribe((res) => {
    this.userRoles = res;
    this.errorMessage = '';
    this.makeCurrentUserSelected();
  }, error => {
    this.showSpinner = false;
    this.snackBar.open(error, '', {
      duration: 3000,
      panelClass: 'alert-error'
    });
  }
  );
}

makeCurrentUserSelected() {
  this.userRoles.forEach(user => {
    if (user.userName === this.currentUser) {
      this.createProjectForm.get('adminAccess').setValue([user]);
    }
  });
}

createProject() {
  const access = [];

  for (const admin of this.createProjectForm.get('adminAccess').value) {
    access.push({email: admin.emailId, roleName: 'admin'});
  }

  for (const developer of this.createProjectForm.get('developerAccess').value) {
    access.push({email: developer.emailId, roleName: 'developer'});
  }

  const formattedStartDateString = this.createProjectForm.get('startDate').value;
  this.formattedStartDate = formattedStartDateString.format('YYYY-MM-DD HH:mm:SS');

  if (this.createProjectForm.get('endDate').value !== '') {
  const formattedEndDateString = this.createProjectForm.get('endDate').value;
  this.formattedEndDate = formattedEndDateString.format('YYYY-MM-DD HH:mm:SS');
  }

  const createProjectData = {
    projectName: this.createProjectForm.get('projectName').value,
    projectDescription: this.createProjectForm.get('projectDescription').value,
    startDate: this.formattedStartDate,
    endDate: this.formattedEndDate,
    access
  };
  console.log(createProjectData);
  this.showSpinner = true;
  this.createProjectService.createProject(createProjectData).subscribe((res: IProjectDetails) => {
    this.showSpinner = false;
    this.notificationService.notify({
      msg: 'Data saved successfully!',
      color: 'alert-success'
    });
    this.projectDetailService.setProjectDetails(res);
    this.router.navigate(['/home/stepper']);
    this.errorMessage = '';
  }, error => {
    this.showSpinner = false;
    this.snackBar.open(error, '', {
      duration: 3000,
      panelClass: 'alert-error'
    });
    this.errorMessage = error;
  }
  );
}

openLandingPage() {
  this.router.navigate(['/home/dashboard']);
}
}
