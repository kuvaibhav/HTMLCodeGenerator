import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {
  projectCount = 0;

  constructor(private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit(): void {
  }

  createProject() {
    console.log('Create New Project Clicked');
    this._router.navigate(['home/create']);
  }

  openProject() {
    this._router.navigate(['home/open']);
  }

}
