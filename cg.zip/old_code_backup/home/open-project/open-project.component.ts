import { Component, OnInit } from '@angular/core';
import { OpenProjectService } from '../../services/http/open-project.service';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { IProjectDetails, ProjectDetailService } from 'src/app/services/utility/project-detail.service';

interface Project {
  projectName: string;
  projectDescription: string;
  startDate: string;
  endDate: string;
  adminResources: string[];
  adminDeveloper: string[];
}

@Component({
  selector: 'app-open-project',
  templateUrl: './open-project.component.html',
  styleUrls: ['./open-project.component.css']
})
export class OpenProjectComponent implements OnInit {
  isHidden: boolean;
  projectsData: any;
  projectsDataClone: any;
  length: number;
  pageIndex = 0;
  pageSize = 10;
  noProjects: boolean;
  search: string;
  projectsList: Project[];
  noResults: boolean;
  formattedEndDate = '';

  constructor(private _router: Router,
              private openProjectService: OpenProjectService,
              private projectDetailService: ProjectDetailService) { }

  ngOnInit(): void {
      this.projectsData = [];
      this.isHidden = true;
      this.noResults = true;
      this.noProjects = true;
      this.getUserProjectsList();
  }

  filteredList() {
    if (this.search === '') {
      this.loadData(this.pageIndex, this.pageSize, this.projectsDataClone);
    } else {
    this.projectsData = this.projectsDataClone.filter((project) =>
      project.projectName.toLowerCase().includes(this.search.toLowerCase())
    );
    this.loadData(this.pageIndex, this.pageSize, this.projectsData);
    }
  }

  OnPageChange(e) {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.loadData(this.pageIndex, this.pageSize, this.projectsDataClone);
  }

  loadData(pageIndex, pageSize, data) {
    const startIndex = pageIndex * pageSize;
    let endIndex = startIndex + pageSize;
    this.length = data.length;
    this.hasResults();
    if (endIndex > this.length) {
      endIndex = this.length;
    }
    this.projectsList = data.slice(startIndex, endIndex);
  }

  hasResults() {
    if (this.projectsData.length === 0) {
      this.noResults = true;
    } else {
      this.noResults = false;
      this.isHidden = false;
    }
  }

  actionAccessible(project) {
    const found = project.adminResources.some(el => el.email === localStorage.getItem('emailId'))
    if (found) {
      return false
    } else {
      return true
    }
}

openLandingPage() {
  this._router.navigate(['/home/dashboard']);
}

openProject(projectDetails: IProjectDetails) {
  this.projectDetailService.setProjectDetails(projectDetails);
  this._router.navigate(['/home/stepper']);
}

  getUserProjectsList() {
    const params = {
      'email': localStorage.getItem('emailId')
    }
    this.openProjectService.getUserProjects(params).subscribe(
      (res: any) => {
        this.isHidden = false;
        res.forEach((project) => {
          const accessAdmins = [];
          const accessDeveloper = [];
          project["access"].forEach((resource) => {
            if (resource.roleName === 'admin') {
              accessAdmins.push(resource);
            } else if (resource.roleName === 'developer') {
              accessDeveloper.push(resource)
            }
          });
          const formattedStartDate = moment(project["startDate"]).format('YYYY-MM-DD')
          if (project["endDate"] !== null) {
            this.formattedEndDate = moment(project["endDate"]).format('YYYY-MM-DD')
          }
          const proj = {
            id: project.id,
            projectName: project.projectName,
            projectDescription: project.projectDescription,
            startDate: formattedStartDate,
            endDate: this.formattedEndDate,
            adminResources: accessAdmins,
            adminDeveloper: accessDeveloper
          } as Project;
          this.projectsData.push(proj);
      });
        this.projectsDataClone = this.projectsData;
        this.length = this.projectsData.length;
        if (this.length > 0) {
          this.noProjects = false;
        }
        this.loadData(this.pageIndex, this.pageSize, this.projectsDataClone);
      },
      (err) => {
        this.openProjectService.alertService({
          msg: 'Oops! Something went wrong. Please try again later.',
          color: 'alert-error',
        });
      }
    );
  }

}
