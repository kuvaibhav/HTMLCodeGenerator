import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material/material.module';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { LandingPageComponent } from './home/landing-page/landing-page.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthService } from './services/http/auth.service';
import { NotificationService } from './services/utility/notification.service';
import { AuthGuard } from 'src/auth.guard';
import { JwtInterceptorService } from './services/utility/jwt-interceptor.service';
import {PasswordValidation} from './login/validators';
import { CreateProjectComponent } from './home/create-project/create-project.component';
import { OpenProjectComponent } from './home/open-project/open-project.component';
import { StepperComponent } from './home/stepper/stepper.component';
import { UploadSectionComponent } from './home/stepper/upload-section/upload-section.component';
import { FileUploadComponent } from './shared/file-upload/file-upload.component';
import { DialogBoxComponent } from './shared/dialog-box/dialog-box.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    LandingPageComponent,
    HeaderComponent,
    FooterComponent,
    CreateProjectComponent,
    OpenProjectComponent,
    StepperComponent,
    UploadSectionComponent,
    FileUploadComponent,
    DialogBoxComponent
  ],
  entryComponents: [
    DialogBoxComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [AuthService, PasswordValidation, AuthGuard, NotificationService, {
    provide: HTTP_INTERCEPTORS,
    useClass: JwtInterceptorService,
    multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
