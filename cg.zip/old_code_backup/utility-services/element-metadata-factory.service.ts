import { Injectable } from '@angular/core';
import { ElementMetaData } from './element-metadata';
import { ElementStructureModel } from '../body/application-body-design/element-structure.model';

@Injectable({
  providedIn: 'root'
})
// This is a simple factory.
export class ElementMetadataFactoryService {
  metadata: ElementStructureModel  = {'title': '', 'position': '', 'buttonText': '', 'fieldName': '', 'code': ''};

  constructor() { }

  public retrieveElementMetaData(element) {
    if (element == 'tb') {
      this.metadata.title = 'Add Text Box';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Commit and Add';
      this.metadata.fieldName = 'Text Box';
      this.metadata.code = 'tb';
    } else if (element == 'cb') {
      this.metadata.title = 'Add Check Box';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Add Check Box';
      this.metadata.fieldName = 'Check Box';
      this.metadata.code = 'cb';
    } else if (element == 'rb') {
      this.metadata.title = 'Add Radio Button';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Add Button';
      this.metadata.fieldName = 'Radio Button';
      this.metadata.code = 'rb';
    } else if (element == 'st') {
      this.metadata.title = 'Add Slide Toggle';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Add Toggle';
      this.metadata.fieldName = 'Slide Toggle';
      this.metadata.code = 'st';
    } else if (element == 'bbtn') {
      this.metadata.title = 'Add Basic Button';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Add Button';
      this.metadata.fieldName = 'Button';
      this.metadata.code = 'bbtn';
    } else if (element == 'bpbtn') {
      this.metadata.title = 'Add Blue Button';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Add Button';
      this.metadata.fieldName = 'Button';
      this.metadata.code = 'bpbtn';
    } else if (element == 'prbtn') {
      this.metadata.title = 'Add Blue Button';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Add Button';
      this.metadata.fieldName = 'Button';
      this.metadata.code = 'prbtn';
    } else if (element == 'lnk') {
      this.metadata.title = 'Add Link';
      this.metadata.position = 'NA';
      this.metadata.buttonText = 'Link';
      this.metadata.fieldName = 'Link';
      this.metadata.code = 'lnk';
    }
    return this.metadata;
  }
}
