import { TestBed } from '@angular/core/testing';

import { ElementMetadataFactoryService } from './element-metadata-factory.service';

describe('ElementMetadataFactoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ElementMetadataFactoryService = TestBed.get(ElementMetadataFactoryService);
    expect(service).toBeTruthy();
  });
});
