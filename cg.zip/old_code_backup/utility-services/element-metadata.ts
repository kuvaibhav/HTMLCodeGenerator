export class ElementMetaData {
    constructor () {}

    public fetchElementMetadata() {};


}