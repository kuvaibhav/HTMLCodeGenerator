import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AuthService } from '../services/http/auth.service';
import {PasswordValidation} from './validators';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  animations: [
    trigger('flipState', [
      state(
        'active',
        style({
          transform: 'rotateY(180deg)',
        })
      ),
      state(
        'inactive',
        style({
          transform: 'rotateY(0)',
        })
      ),
      transition('active => inactive', animate('0.2s ease-out')),
      transition('inactive => active', animate('0.2s ease-in')),
    ]),
  ],
})

export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  signupForm: FormGroup;
  flip = 'inactive';
  noflip = 'active';
  submitted = false;
  errorMessage = '';
  showSpinner = false;
/**
 * Creates an instance of LoginComponent.
 * @param router: A router instance that provides navigations to different paths.
 * @param _authService: Instance of authorization service
 */
constructor(private router: Router, private _authService: AuthService) { }

  ngOnInit(): void {
    this.initLoginForm();
    this.initSignupForm();
  }

  initLoginForm() {
    this.loginForm = new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl(null, Validators.required)
    });
  }

  initSignupForm() {
    this.signupForm = new FormGroup({
      passwordSignup: new FormControl('', Validators.required),
      confirmPassword: new FormControl('', [Validators.required,
        (control => PasswordValidation.confirmPassword(control, this.signupForm, 'passwordSignup'))]),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      usernameSignup: new FormControl('', Validators.required),
      emailId: new FormControl('', Validators.required),
      userRole: new FormControl('', Validators.required)
  });
  }

  login(){
    const loginUserData = {
      userName: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    this.showSpinner = true;
    this._authService.login(loginUserData).subscribe((res) => {
      this.showSpinner = false;
      this.errorMessage = '';
      //storing jwt token
      console.log(res);
      localStorage.setItem('token', res.userName);
      localStorage.setItem('emailId', res.emailId);
      //showSpinner and navigate to Home Component
      this.router.navigate(['/home']);
    },
    error => {
      this.showSpinner = false;
      //show error on a toaster
      console.log('Inside TS error block');
      this.errorMessage = error;
    });
  }

  register() {
    const signupData = {
      userName: this.signupForm.get('usernameSignup').value,
      firstName: this.signupForm.get('firstName').value,
      lastName: this.signupForm.get('lastName').value,
      password: this.signupForm.get('passwordSignup').value,
      emailId: this.signupForm.get('emailId').value,
      userRole: this.signupForm.get('userRole').value
    }
    this.showSpinner = true;
    this._authService.register(signupData).subscribe((res) => {
      this.showSpinner = false;
      this.errorMessage = '';
      this.toggleFlip();
    }, error => {
      this.showSpinner = false;
      this.errorMessage = error;
    }
    );
  }

  toggleFlip() {
    this.flip = this.flip === 'inactive' ? 'active' : 'inactive';
    this.noflip = this.flip === 'inactive' ? 'active' : 'inactive';
  }

}
