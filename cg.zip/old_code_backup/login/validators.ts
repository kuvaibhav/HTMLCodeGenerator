import { FormGroup, FormControl, AbstractControl} from '@angular/forms';

export class PasswordValidation {
    static confirmPassword(control: AbstractControl, group: FormGroup, matchPassword: string) {
        if (control?.value && group?.controls && group?.controls[matchPassword].value !== null 
            && group?.controls[matchPassword].value === control?.value) {
            return null;
        }
        return { 'mismatch': true }
    }   
  }