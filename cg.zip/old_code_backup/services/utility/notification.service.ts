import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NotificationComponent } from './../../shared/notification/notification.component';

export interface INotification {
  msg: string;
  color: string;
}

@Injectable()
export class NotificationService {
  durationInSeconds = 5;

  constructor(private snackBar: MatSnackBar) {}

  notify(notification: INotification) {
    setTimeout(() => {
      this.snackBar.openFromComponent(NotificationComponent, {
        duration: this.durationInSeconds * 1000,
        data: notification.msg,
        panelClass: notification.color,
      });
    }, 0);
  }
}
