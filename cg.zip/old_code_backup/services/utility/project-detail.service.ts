import { Injectable } from '@angular/core';

export class IAccess {
  email: string;
  roleName: string;
}

export class IProjectDetails {
  id: string;
  projectName: string;
  projectDescription: string;
  startDate: any;
  endDate: any;
  access: Array<IAccess>;
}

@Injectable({
  providedIn: 'root'
})
export class ProjectDetailService {
  private currentProjectDetails: IProjectDetails;
  constructor() { }

  public setProjectDetails(projectDetails: IProjectDetails) {
    this.currentProjectDetails = projectDetails;
  }

  public getProjectDetails(): IProjectDetails {
    return this.currentProjectDetails;
  }
}
