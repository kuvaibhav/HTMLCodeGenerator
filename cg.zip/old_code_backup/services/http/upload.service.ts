import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadService {
  private SERVER_URL = environment.domain.projectDetails + 'projectFile/add';
  private fetchFileUrl = environment.domain.projectDetails + 'projectFile/getFilesByProject';

  constructor(private httpClient: HttpClient) { }

  public upload(formData: FormData) {
    return this.httpClient.post<any>(this.SERVER_URL, formData, {
      reportProgress: true,
      observe: 'events'
    }).pipe(
      catchError(this.handleErrorAndReturnErrorObject)
    );
  }

  public fetchUploadedFile(projectId: string, fileType: string) {
    let params = new HttpParams();
    params = params.set('projectId', projectId);
    params = params.set('fileType', fileType);
    return this.httpClient.get<any>(this.fetchFileUrl, {params}).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.log('Inside handle error block');
    return throwError(error.message);
  }

  private handleErrorAndReturnErrorObject(error: HttpErrorResponse) {
    console.log('Inside handle error block');
    return throwError(error.error);
  }
}
