import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _loginUrl = environment.domain.user + 'user/login';
  private _registerUrl = environment.domain.user + 'user/saveUser';

  constructor(private http: HttpClient) { }

  public login(userObj): Observable<any> {
    return this.http.post<any>(this._loginUrl, userObj).pipe(
      catchError(this.handleError)
    );
  }

  public register(userObj): Observable<any> {
    return this.http.post<any>(this._registerUrl, userObj).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.log('Inside handle error block');
    return throwError(error.message);
  }

  public isUserLogged() {
    //double negate will return boolean
    return !!localStorage.getItem('token')
  }

  public getToken() {
    return localStorage.getItem('token');
  }
}
