import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NotificationService, INotification } from '../utility/notification.service';

@Injectable({
    providedIn: 'root'
  })

  export class OpenProjectService {

    private _openProjectUrl = environment.domain.projectDetails + 'projectDetail/findProjectDetail';

    constructor(private http: HttpClient, private notificationService: NotificationService) { }

    public getUserProjects(params): Observable<any> {
        return this.http.get<any>(this._openProjectUrl, {params}).pipe(
          catchError(this.handleError)
        );
      }

      private handleError(error: HttpErrorResponse) {
        console.log('Inside handle error block');
        return throwError(error.message);
      }

      alertService(data: INotification) {
        this.notificationService.notify(data);
      }
  }
