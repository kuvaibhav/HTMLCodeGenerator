import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { IProjectDetails } from '../utility/project-detail.service';

@Injectable({
    providedIn: 'root'
  })

  export class CreateProjectAuthService {

    private _createProjectUrl = environment.domain.projectDetails + 'projectDetail/saveProjectDetail';
    private _getAllUsersUrl = environment.domain.user + 'user/getAllUsers';

    constructor(private http: HttpClient) { }

    public getAllUsers(): Observable<any> {
        return this.http.get<any>(this._getAllUsersUrl).pipe(
          catchError(this.handleError)
        );
      }

  public createProject(userObj): Observable<IProjectDetails> {
    return this.http.post<any>(this._createProjectUrl, userObj).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.log('Inside handle error block');
    return throwError(error.message);
  }

  }
