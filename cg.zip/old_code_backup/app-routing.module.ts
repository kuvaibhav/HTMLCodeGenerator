import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from 'src/auth.guard';
import { LandingPageComponent } from './home/landing-page/landing-page.component';
import { CreateProjectComponent } from './home/create-project/create-project.component';
import { OpenProjectComponent } from './home/open-project/open-project.component';
import { StepperComponent } from './home/stepper/stepper.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    // redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuard],
    children: [
      {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
      {path: 'dashboard', component: LandingPageComponent, canActivate: [AuthGuard]},
      {path: 'create', component: CreateProjectComponent, canActivate: [AuthGuard]},
      {path: 'open', component: OpenProjectComponent, canActivate: [AuthGuard]},
      {path: 'stepper', component: StepperComponent, canActivate: [AuthGuard]}
    ]
    // canActivate: [AuthGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '**',
    redirectTo: '/login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
